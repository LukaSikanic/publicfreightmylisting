<div id="comparison-view" class="modal modal-27" role="dialog">
	<div class="modal-dialog">
		<div class="modal-content"></div>
	</div>
	<div class="loader-bg">
		<?php c27()->get_partial( 'spinner', [
			'color' => '#ddd',
			'classes' => 'center-vh',
			'size' => 28,
			'width' => 3,
		] ) ?>
	</div>
</div>