<div class="no-results-wrapper">
	<i class="no-results-icon mi mood_bad"></i>
	<li class="no_job_listings_found"><?php _e( 'There are no listings matching your search.', 'my-listing' ) ?></li>
</div>