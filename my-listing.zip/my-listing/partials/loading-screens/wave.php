<?php wp_print_styles('mylisting-wave') ?>
<div class="loader-bg main-loader background-color" style="background-color: <?php echo esc_attr( c27()->get_setting( 'general_loading_overlay_background_color' ,'#ffffff' ) ) ?>;">
	<div class="sk-wave">
		<div class="sk-rect sk-rect1" style="background-color: <?php echo esc_attr( c27()->get_setting( 'general_loading_overlay_color' ,'#000000' ) ) ?>;"></div>
		<div class="sk-rect sk-rect2" style="background-color: <?php echo esc_attr( c27()->get_setting( 'general_loading_overlay_color' ,'#000000' ) ) ?>;"></div>
		<div class="sk-rect sk-rect3" style="background-color: <?php echo esc_attr( c27()->get_setting( 'general_loading_overlay_color' ,'#000000' ) ) ?>;"></div>
		<div class="sk-rect sk-rect4" style="background-color: <?php echo esc_attr( c27()->get_setting( 'general_loading_overlay_color' ,'#000000' ) ) ?>;"></div>
		<div class="sk-rect sk-rect5" style="background-color: <?php echo esc_attr( c27()->get_setting( 'general_loading_overlay_color' ,'#000000' ) ) ?>;"></div>
	</div>
</div>