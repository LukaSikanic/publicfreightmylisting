<?php

namespace MyListing;

if ( ! defined('ABSPATH') ) {
	exit;
}

return [
	// to do after 2.11.6
	'styles' => [
		// 'backend.css',
	],

	'scripts' => [
		[
			'src' => 'basic-search-form',
			'deps' => [ 'c27-main' ],
		],
		[
			'src' => 'explore',
			'deps' => [ 'c27-main' ],
		],
		// to do: add all script handles here
	],
];
