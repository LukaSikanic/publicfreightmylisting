<?php require locate_template( 'templates/emails/partials/header.php' ) ?>

<?php echo $this->get_message() ?>

<?php require locate_template( 'templates/emails/partials/footer.php' ) ?>