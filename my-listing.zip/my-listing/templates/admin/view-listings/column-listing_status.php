<?php

// @todo custom icons for different statuses
echo esc_html( $listing->get_status() );