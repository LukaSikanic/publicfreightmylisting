<?php
/**
 * Template Name: Content + Full Width Featured Image
 */

get_header(); the_post();

	get_template_part( 'templates/content' );

get_footer();