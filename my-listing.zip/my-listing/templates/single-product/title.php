<?php
/**
 * Single Product title
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

the_title( '<h1 class="product_title entry-title case27-primary-text">', '</h1>' );
